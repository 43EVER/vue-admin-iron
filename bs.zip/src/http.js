import axios from "axios";

const http = axios.create({
  baseURL: "http://192.168.3.9:8080"
});


// http.interceptors.request.use(config => {
//   return config;
// })

export default http;
